$summon armor_stand ~ ~ ~ {NoGravity:0b,Motion:$(motion),Invulnerable:1b,Small:1b,Invisible:1b,equipment:{saddle:{id:"minecraft:oak_button",count:1,components:{"minecraft:item_model":"air","minecraft:enchantments":{"infinity_cave:technical/chemical_bomb":$(strength)}}}}}

kill @s