tp ^ ^0.5 ^1
data modify storage infinity_cave:motion Motion set from entity @s Pos
kill @s