playsound minecraft:block.respawn_anchor.deplete block @a[distance=..16] ~ ~ ~ 1 1
tellraw @s[tag=!bistro.portal_informed] {"text":"The End Portal Frame is frozen by magic. You will need to find a Portal Frame Key to free it."}
tag @s add bistro.portal_informed