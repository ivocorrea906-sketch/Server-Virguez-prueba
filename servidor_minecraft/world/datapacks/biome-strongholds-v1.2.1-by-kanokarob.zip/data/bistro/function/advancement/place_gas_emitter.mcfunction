advancement revoke @s only bistro:place_gas_emitter
execute anchored eyes positioned ^ ^ ^0.25 run function bistro:advancement/place_gas_emitter/find_block