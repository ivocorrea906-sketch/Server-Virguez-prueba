scoreboard players set @n[tag=bistro.chest_master,distance=..14] bistro.state 0
playsound minecraft:block.respawn_anchor.deplete block @a[distance=..16] ~ ~ ~ 1 2