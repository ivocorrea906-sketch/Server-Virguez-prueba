scoreboard players set @s bistro.temp 1
scoreboard players operation @s bistro.temp += @n[tag=bistro.chest_master,distance=..14] bistro.state
execute at @n[tag=bistro.chest_master,distance=..14] at @e[tag=bistro.chest,distance=..14,limit=4,sort=nearest] run data modify block ~ ~ ~ LootTable set value "bistro:chests/puzzle_chest"
execute positioned ~ ~0.5 ~ summon text_display run function bistro:advancement/open_puzzle_chest/chest/text_display
execute if score @s bistro.state = @s bistro.temp run return run function bistro:advancement/open_puzzle_chest/chest/correct
execute unless score @s bistro.state = @s bistro.temp run return run function bistro:advancement/open_puzzle_chest/chest/incorrect