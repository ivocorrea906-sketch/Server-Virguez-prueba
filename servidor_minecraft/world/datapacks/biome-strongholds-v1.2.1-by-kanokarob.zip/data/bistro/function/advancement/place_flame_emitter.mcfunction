advancement revoke @s only bistro:place_flame_emitter
execute anchored eyes positioned ^ ^ ^0.25 run function bistro:advancement/place_flame_emitter/find_block