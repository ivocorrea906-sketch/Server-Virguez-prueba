scoreboard players add @n[tag=bistro.chest_master,distance=..14] bistro.state 1
playsound minecraft:block.end_portal_frame.fill block @a[distance=..16] ~ ~ ~ 1 2