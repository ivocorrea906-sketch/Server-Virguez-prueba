advancement revoke @s only bistro:open_puzzle_chest
execute anchored eyes positioned ^ ^ ^1.5 as @n[tag=bistro.chest,distance=..3] at @s run function bistro:advancement/open_puzzle_chest/chest