playsound minecraft:block.respawn_anchor.charge block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:block.glass.break block @a[distance=..16] ~ ~ ~ 0.65 1
particle poof ~ ~0.5 ~ 0.3 0.3 0.3 0.05 10 normal
particle dragon_breath ~ ~0.5 ~ 0.5 0.5 0.5 0.05 30 normal
execute on passengers run kill @s
kill @s