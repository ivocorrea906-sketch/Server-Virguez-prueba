scoreboard players remove @s bistro.timer.jumpless 1
scoreboard players remove @s bistro.timer.sound 1
execute if predicate bistro:chance/5 run particle minecraft:snowflake ~ ~0.3 ~ 0.2 0.1 0.2 0.005 5 normal
execute if predicate bistro:jump_key unless score @s bistro.timer.sound matches 1.. run function bistro:schedule/countdown/sound
execute if score @s bistro.timer.jumpless matches 0 run function bistro:schedule/countdown/end