execute as @a[tag=bistro.jumpless] at @s run function bistro:schedule/countdown
execute if entity @a[tag=bistro.jumpless] run schedule function bistro:schedule/player_jumpless 1t replace