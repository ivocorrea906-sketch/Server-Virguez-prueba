tag @s remove bistro.jumpless
scoreboard players reset @s bistro.timer.jumpless
scoreboard players reset @s bistro.timer.sound
attribute @s minecraft:jump_strength modifier remove bistro:jumpless