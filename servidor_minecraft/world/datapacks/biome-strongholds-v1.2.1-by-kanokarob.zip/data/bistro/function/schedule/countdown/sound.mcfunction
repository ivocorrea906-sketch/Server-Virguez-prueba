playsound minecraft:entity.player.hurt_freeze player @s ~ ~ ~ 1 1
scoreboard players set @s bistro.timer.sound 30