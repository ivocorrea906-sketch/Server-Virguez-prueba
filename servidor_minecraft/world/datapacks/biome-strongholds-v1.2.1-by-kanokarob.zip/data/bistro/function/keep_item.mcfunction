data modify entity @s Age set value -32768s
tag @s add bistro.immortal