function bistro:tick_entities/technical/traps/trick_ceiling/summon_spike
playsound minecraft:entity.breeze.death block @a ~ ~ ~ 0.7 2
particle poof ~ ~0.1 ~ 0.3 0.1 0.3 0.05 5 normal
scoreboard players reset @s
kill @s