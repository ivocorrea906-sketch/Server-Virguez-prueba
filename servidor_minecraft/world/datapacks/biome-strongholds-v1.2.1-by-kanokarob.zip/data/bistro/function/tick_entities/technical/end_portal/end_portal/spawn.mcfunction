execute as @a at @s run playsound minecraft:block.end_portal.spawn block @s ~ ~ ~ 1 1
scoreboard players reset @s
execute positioned ~ ~1 ~ run function bistro:tick_entities/technical/end_portal/end_portal/end_portal/particles_spawn
fill ~-1 ~ ~-1 ~1 ~ ~1 end_portal
kill @e[tag=bistro.ender_eye,predicate=bistro:end_frame_filled,distance=..40]
kill @s