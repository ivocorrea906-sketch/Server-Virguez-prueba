damage @s 4.0 minecraft:mob_attack by @n[tag=bistro.attacker,distance=..3]
playsound minecraft:entity.generic.explode hostile @a[distance=..16] ~ ~ ~ 1 1.4
particle minecraft:explosion ~ ~0.5 ~ 0 0 0 0 1 normal
scoreboard players set @n[tag=bistro.attacker,distance=..3] bistro.timer 30