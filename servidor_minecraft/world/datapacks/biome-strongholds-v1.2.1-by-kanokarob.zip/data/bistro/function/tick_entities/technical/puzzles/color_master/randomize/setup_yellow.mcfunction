tag @s add bistro.color.yellow
tag @s add bistro.initialized