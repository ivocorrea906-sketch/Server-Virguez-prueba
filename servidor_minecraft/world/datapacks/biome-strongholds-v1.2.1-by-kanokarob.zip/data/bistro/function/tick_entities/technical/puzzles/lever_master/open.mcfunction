tag @s add bistro.open
playsound minecraft:block.grindstone.use block @a[distance=..16] ~ ~ ~ 1 0.7
playsound minecraft:block.piston.contract block @a[distance=..16] ~ ~ ~ 1 1
particle minecraft:poof ~ ~ ~ 0.2 0.5 0.2 0.05 5 normal
fill ~ ~-1 ~ ~ ~ ~ minecraft:air replace