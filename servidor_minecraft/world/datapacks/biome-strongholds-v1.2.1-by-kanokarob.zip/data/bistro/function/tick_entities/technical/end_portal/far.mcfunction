particle reverse_portal ~ ~ ~ ^ ^ ^100000000 0.000000003 0 normal
particle reverse_portal ~0.15 ~ ~ ^ ^ ^100000000 0.000000003 0 normal
particle reverse_portal ~-0.15 ~ ~ ^ ^ ^100000000 0.000000003 0 normal
particle reverse_portal ~ ~ ~0.15 ^ ^ ^100000000 0.000000003 0 normal
particle reverse_portal ~ ~ ~-0.15 ^ ^ ^100000000 0.000000003 0 normal