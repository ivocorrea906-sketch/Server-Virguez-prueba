loot insert ~ ~ ~ loot bistro:chests/stronghold/chest_treasure
data remove block ~ ~ ~ lock
particle minecraft:firework ~ ~ ~ 0.4 0.4 0.4 0.15 10 normal
playsound minecraft:entity.firework_rocket.launch block @a[distance=..16] ~ ~ ~ 1 1
kill @s