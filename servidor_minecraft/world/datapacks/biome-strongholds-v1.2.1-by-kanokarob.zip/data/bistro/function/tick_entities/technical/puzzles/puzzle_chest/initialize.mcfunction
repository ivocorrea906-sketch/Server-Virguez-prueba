data merge entity @s {item:{id:"minecraft:copper_chest",count:1},transformation:{scale:[1.0f,1.0f,1.0f],translation:[0.0f,1.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},teleport_duration:1}
loot insert ~ ~ ~ loot bistro:commands/puzzle_chest_keys
data modify entity @s item set from block ~ ~ ~ Items[0]
data modify block ~ ~ ~ lock.items set from entity @s item.id
item replace block ~ ~ ~ container.0 with minecraft:air 1
data modify block ~ ~ ~ LootTable set value "bistro:chests/puzzle_chest"
playsound minecraft:entity.player.levelup block @a[distance=..16] ~ ~ ~ 1 2
particle minecraft:electric_spark ~ ~ ~ 0.4 0.4 0.4 0.2 10 normal
tag @s add bistro.initialized