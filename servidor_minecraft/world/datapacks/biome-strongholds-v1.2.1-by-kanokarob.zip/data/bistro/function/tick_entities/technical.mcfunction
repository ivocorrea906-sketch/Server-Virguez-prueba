execute if entity @s[tag=bistro.trap] run return run function bistro:tick_entities/technical/traps
execute if entity @s[tag=bistro.puzzle] run return run function bistro:tick_entities/technical/puzzles/tick
execute if entity @s[tag=bistro.trap_pot] unless block ~ ~ ~ minecraft:decorated_pot run return run function bistro:tick_entities/technical/trap_pots
execute if entity @s[tag=bistro.end_portal] run function bistro:tick_entities/technical/end_portal
execute if entity @s[tag=bistro.portal_key] if entity @a[distance=..32] run function bistro:tick_entities/technical/portal_key
execute if entity @s[tag=bistro.cauldron] run function bistro:tick_entities/technical/cauldron