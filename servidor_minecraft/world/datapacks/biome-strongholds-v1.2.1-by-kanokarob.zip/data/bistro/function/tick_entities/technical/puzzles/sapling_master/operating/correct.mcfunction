kill @n[tag=bistro.sapling_hat,distance=..12]
kill @n[tag=bistro.sapling,distance=..12]
kill @e[tag=bistro.hiding_spot,distance=..12]
execute as @n[tag=bistro.sapling_reward,distance=..9] at @s run function bistro:tick_entities/technical/puzzles/sapling_master/operating/correct/reward
playsound minecraft:ui.toast.challenge_complete block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.player.levelup block @a[distance=..16] ~ ~ ~ 1 2
kill @s