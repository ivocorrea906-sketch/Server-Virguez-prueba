tag @s add bistro.initialized
execute as @e[tag=bistro.portal_barrier,distance=..15,limit=12,sort=nearest] at @s run function bistro:tick_entities/technical/end_portal/portal_barriers
kill @e[tag=bistro.portal_key,tag=!bistro.initialized]