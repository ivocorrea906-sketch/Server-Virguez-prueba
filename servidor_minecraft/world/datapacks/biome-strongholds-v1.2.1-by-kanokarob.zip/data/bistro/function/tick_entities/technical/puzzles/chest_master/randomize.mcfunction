execute as @e[tag=bistro.chest,tag=!bistro.initialized,limit=1,sort=random,distance=..14] at @s run function bistro:tick_entities/technical/puzzles/chest_master/randomize/setup_1
execute as @e[tag=bistro.chest,tag=!bistro.initialized,limit=1,sort=random,distance=..14] at @s run function bistro:tick_entities/technical/puzzles/chest_master/randomize/setup_2
execute as @e[tag=bistro.chest,tag=!bistro.initialized,limit=1,sort=random,distance=..14] at @s run function bistro:tick_entities/technical/puzzles/chest_master/randomize/setup_3
execute as @e[tag=bistro.chest,tag=!bistro.initialized,limit=1,sort=random,distance=..14] at @s run function bistro:tick_entities/technical/puzzles/chest_master/randomize/setup_4
execute as @e[tag=bistro.chest,tag=!bistro.initialized,limit=9,sort=random,distance=..14] at @s run function bistro:tick_entities/technical/puzzles/chest_master/randomize/remove
tag @s add bistro.initialized
scoreboard players set @s bistro.state 0
setblock ~ ~ ~ minecraft:air replace
playsound minecraft:block.trial_spawner.detect_player block @a[distance=..16] ~ ~ ~ 1 1.6 1
playsound minecraft:entity.blaze.death block @a[distance=..16] ~ ~ ~ 0.4 2 0.4