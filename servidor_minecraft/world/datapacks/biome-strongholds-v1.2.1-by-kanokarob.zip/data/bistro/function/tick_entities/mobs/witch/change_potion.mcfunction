summon minecraft:lingering_potion ~ ~ ~ {Tags:[bistro.new_potion]}
data modify entity @n[tag=bistro.new_potion,distance=..0.1] Item set from entity @s Item
data modify entity @n[tag=bistro.new_potion,distance=..0.1] potion_contents set from entity @s potion_contents
data modify entity @n[tag=bistro.new_potion,distance=..0.1] Rotation set from entity @s Rotation
data modify entity @n[tag=bistro.new_potion,distance=..0.1] Motion set from entity @s Motion
data modify entity @n[tag=bistro.new_potion,distance=..0.1] Owner set from entity @s Owner
kill @s