scoreboard players add @s bistro.timer 0
tp @s ~ ~-0.35 ~
execute if entity @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..0.75] run function bistro:tick_entities/technical/traps/spike/damage
execute if score @s bistro.timer matches 5.. unless block ~ ~ ~ #minecraft:air run function bistro:tick_entities/technical/traps/spike/damage
scoreboard players add @s bistro.timer 1