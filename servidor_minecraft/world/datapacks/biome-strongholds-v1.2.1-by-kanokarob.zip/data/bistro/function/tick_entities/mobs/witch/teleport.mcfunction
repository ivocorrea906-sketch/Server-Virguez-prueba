execute unless entity @a[distance=..2.5] run return 0
execute at @p[distance=..2.5] rotated ~ 0 unless block ^ ^ ^-1.5 #bistro:nonsolid run return 0
particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.01 2 normal
particle minecraft:poof ~ ~1 ~ 0.3 0.5 0.3 0.02 5 normal
playsound minecraft:entity.illusioner.mirror_move hostile @a[distance=..16] ~ ~ ~
execute at @p[distance=..2.5] rotated ~ 0 if block ^ ^0.5 ^-1.5 #bistro:nonsolid run tp @s ^ ^0.5 ^-1.5
execute at @s run particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.01 2 normal
execute at @s run particle minecraft:poof ~ ~1 ~ 0.3 0.5 0.3 0.02 5 normal
scoreboard players set @s bistro.timer 40