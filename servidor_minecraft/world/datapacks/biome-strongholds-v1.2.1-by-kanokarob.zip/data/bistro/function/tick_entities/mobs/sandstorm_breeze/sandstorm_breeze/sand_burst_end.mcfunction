scoreboard players reset @s bistro.timer
tag @s remove bistro.sand_burst
particle poof ~ ~1 ~ 0.5 0.3 0.5 0.2 2 normal
playsound minecraft:entity.breeze.charge hostile @a ~ ~ ~ 1 1.3