tag @s add bistro.jumpless
attribute @s minecraft:jump_strength modifier add bistro:jumpless -1 add_multiplied_total
scoreboard players set @s bistro.timer.jumpless 200
schedule function bistro:schedule/player_jumpless 1t replace