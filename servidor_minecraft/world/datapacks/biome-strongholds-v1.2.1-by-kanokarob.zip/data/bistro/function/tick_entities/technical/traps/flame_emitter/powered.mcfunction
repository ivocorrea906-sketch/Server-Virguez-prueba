execute if block ~ ~ ~ dispenser[facing=east] facing ~1 ~ ~ if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect
execute if block ~ ~ ~ dispenser[facing=west] facing ~-1 ~ ~ if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect
execute if block ~ ~ ~ dispenser[facing=south] facing ~ ~ ~1 if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect
execute if block ~ ~ ~ dispenser[facing=north] facing ~ ~ ~-1 if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect
execute if block ~ ~ ~ dispenser[facing=up] facing ~ ~1 ~ if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect
execute if block ~ ~ ~ dispenser[facing=down] facing ~ ~-1 ~ if block ^ ^ ^1 #bistro:nonsolid run function bistro:tick_entities/technical/traps/flame_emitter/effect