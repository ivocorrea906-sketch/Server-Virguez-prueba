fill ^-1 ^-1 ^ ^1 ^-1 ^ minecraft:waxed_cut_copper
fill ^-1 ^ ^ ^1 ^1 ^ minecraft:waxed_copper_block
setblock ^ ^ ^ minecraft:waxed_copper_bulb[lit=true]
setblock ^ ^1 ^ minecraft:waxed_chiseled_copper