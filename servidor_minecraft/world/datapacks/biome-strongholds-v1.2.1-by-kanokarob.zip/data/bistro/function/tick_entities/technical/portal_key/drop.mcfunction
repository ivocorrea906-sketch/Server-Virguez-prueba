playsound minecraft:block.vault.activate block @a[distance=..8] ~ ~ ~ 0.65 1
playsound minecraft:entity.player.levelup block @a[distance=..8] ~ ~ ~ 1 2
particle minecraft:poof ~ ~ ~ 0.5 0.5 0.5 0.07 10 normal
particle minecraft:dragon_breath ~ ~ ~ 0.3 0.3 0.3 0.1 30 normal
loot spawn ~ ~ ~ loot bistro:items/portal_key
kill @s