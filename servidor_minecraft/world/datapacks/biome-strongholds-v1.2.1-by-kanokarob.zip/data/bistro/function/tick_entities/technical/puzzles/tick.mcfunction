execute if entity @s[tag=bistro.secret_button] run function bistro:tick_entities/technical/puzzles/secret_button
execute if entity @s[tag=bistro.lever_master] run function bistro:tick_entities/technical/puzzles/lever_master
execute if entity @s[tag=bistro.color_master] run function bistro:tick_entities/technical/puzzles/color_master
execute if entity @s[tag=bistro.bookshelf_master] run function bistro:tick_entities/technical/puzzles/bookshelf_master
execute if entity @s[tag=bistro.chest_master] run function bistro:tick_entities/technical/puzzles/chest_master
execute if entity @s[tag=bistro.text_display] run function bistro:tick_entities/technical/puzzles/text_display
execute if entity @s[tag=bistro.sapling_master] run function bistro:tick_entities/technical/puzzles/sapling_master
execute if entity @s[tag=bistro.puzzle_chest] run function bistro:tick_entities/technical/puzzles/puzzle_chest