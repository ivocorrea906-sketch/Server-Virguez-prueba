rotate @s ~3 0
particle minecraft:portal ~ ~ ~ 0 0 0 0.35 1 normal
execute if entity @a[gamemode=!creative,gamemode=!spectator,distance=..1.25] run function bistro:tick_entities/technical/portal_key/drop