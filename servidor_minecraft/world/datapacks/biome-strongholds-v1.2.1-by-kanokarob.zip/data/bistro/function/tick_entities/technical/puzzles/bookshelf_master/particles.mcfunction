execute unless predicate bistro:bookshelf_correct run particle raid_omen ~ ~ ~ 0.3 0.3 0.3 0.001 5 normal
execute unless predicate bistro:bookshelf_correct run playsound minecraft:entity.villager.work_librarian block @a[distance=..16] ~ ~ ~ 1 1.7
execute if predicate bistro:bookshelf_correct run particle happy_villager ~ ~ ~ 0.3 0.3 0.3 0.001 5 normal