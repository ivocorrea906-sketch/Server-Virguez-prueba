setblock ~ ~-1 ~ minecraft:polished_tuff
setblock ~ ~ ~ minecraft:mossy_cobblestone