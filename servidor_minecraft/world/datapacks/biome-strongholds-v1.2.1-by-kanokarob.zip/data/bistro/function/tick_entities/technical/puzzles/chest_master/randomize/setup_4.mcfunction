scoreboard players set @s bistro.state 4
data modify block ~ ~ ~ LootTable set value "bistro:chests/puzzle_chest"
tag @s add bistro.initialized