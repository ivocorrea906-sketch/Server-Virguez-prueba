execute if entity @s[tag=bistro.color.red] run function bistro:tick_entities/technical/puzzles/color_master/operating/test/red
execute if entity @s[tag=bistro.color.green] run function bistro:tick_entities/technical/puzzles/color_master/operating/test/green
execute if entity @s[tag=bistro.color.blue] run function bistro:tick_entities/technical/puzzles/color_master/operating/test/blue
execute if entity @s[tag=bistro.color.yellow] run function bistro:tick_entities/technical/puzzles/color_master/operating/test/yellow