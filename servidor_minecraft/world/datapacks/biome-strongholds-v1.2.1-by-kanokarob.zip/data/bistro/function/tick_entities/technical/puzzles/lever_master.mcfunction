execute store result score @s bistro.temp if entity @e[tag=bistro.lever,distance=..8,sort=nearest,predicate=bistro:lever_powered]
execute if entity @s[tag=bistro.lever_count.1] run scoreboard players set @s bistro.state 1
execute if entity @s[tag=bistro.lever_count.2] run scoreboard players set @s bistro.state 2
execute unless entity @s[tag=bistro.open] if score @s bistro.temp >= @s bistro.state at @e[tag=bistro.secret_door,distance=..9] run function bistro:tick_entities/technical/puzzles/lever_master/open
execute if entity @s[tag=bistro.open] unless score @s bistro.temp >= @s bistro.state at @e[tag=bistro.secret_door,distance=..9] run function bistro:tick_entities/technical/puzzles/lever_master/close