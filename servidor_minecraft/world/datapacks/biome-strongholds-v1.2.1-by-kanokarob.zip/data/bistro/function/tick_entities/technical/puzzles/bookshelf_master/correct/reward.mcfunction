place jigsaw bistro:jungle/deco/loot_treasure bistro:effect 1 ~ ~1 ~
kill @s