playsound minecraft:entity.blaze.death block @a ~ ~ ~ 0.7 2
particle smoke ~ ~0.1 ~ 0.3 0.1 0.3 0.05 5 normal
loot replace entity @n[type=item,distance=..1] contents loot bistro:blocks/flame_emitter
kill @s