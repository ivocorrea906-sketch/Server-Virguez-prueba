scoreboard players add @s bistro.timer 0
execute if score @s bistro.timer matches 40.. run function bistro:tick_entities/technical/end_portal/end_portal/spawn
execute if entity @a[distance=..8,predicate=!bistro:in_water] run scoreboard players add @s bistro.timer 1