tp @s ~ ~0.02 ~
execute if score @s bistro.timer matches 50.. run kill @s
scoreboard players add @s bistro.timer 1