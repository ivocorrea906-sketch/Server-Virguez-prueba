execute if predicate bistro:in_jungle_stronghold run return run place jigsaw bistro:jungle/deco/loot_treasure bistro:effect 1 ~ ~1 ~
execute if predicate bistro:in_forest_stronghold run return run place jigsaw bistro:forest/deco/loot_treasure bistro:effect 1 ~ ~1 ~
kill @s