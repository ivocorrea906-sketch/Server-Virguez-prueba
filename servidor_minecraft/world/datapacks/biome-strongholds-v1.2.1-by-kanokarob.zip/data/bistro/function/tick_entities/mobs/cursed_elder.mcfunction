effect clear @s minecraft:mining_fatigue
effect give @s minecraft:blindness 30 0 false