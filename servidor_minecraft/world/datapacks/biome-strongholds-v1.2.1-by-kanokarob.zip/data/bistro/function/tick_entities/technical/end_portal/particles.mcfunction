execute positioned ~ ~0.6 ~ facing entity @s[distance=15.1..] feet run function bistro:tick_entities/technical/end_portal/extreme
execute positioned ~ ~0.6 ~ facing entity @s[distance=7.1..15] feet run function bistro:tick_entities/technical/end_portal/far
execute positioned ~ ~0.6 ~ facing entity @s[distance=..7] feet run function bistro:tick_entities/technical/end_portal/near