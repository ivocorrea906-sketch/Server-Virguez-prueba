playsound minecraft:entity.breeze.charge block @a ~ ~ ~ 0.5 1
particle minecraft:dust_pillar{block_state:"minecraft:slime_block"} ~ ~ ~ 0 0 0 0.01 3 normal
execute align xyz run effect give @e[type=!#bistro:ignore,type=!#bistro:trap_immune,dx=0,dy=2,dz=0,predicate=!bistro:poisoned] minecraft:poison 15 0 false