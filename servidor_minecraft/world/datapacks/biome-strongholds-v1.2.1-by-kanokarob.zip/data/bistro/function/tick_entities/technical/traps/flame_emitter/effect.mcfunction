playsound minecraft:entity.breeze.charge block @a[distance=..16] ~ ~ ~ 0.35 0.65
execute if predicate bistro:chance/5 run playsound minecraft:entity.blaze.shoot block @a[distance=..16] ~ ~ ~ 0.7 1.45
particle flame ^ ^0.1 ^0.4 ^ ^ ^100000000 0.000000004 0 normal
particle flame ^0.065 ^-0.065 ^0.4 ^ ^ ^80000000 0.000000004 0 normal
particle flame ^-0.065 ^-0.065 ^0.4 ^ ^ ^80000000 0.000000004 0 normal
execute positioned ^ ^-0.25 ^1 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..2]
execute positioned ^ ^ ^2 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^2 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..3]
execute positioned ^ ^ ^3 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^3 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..4]
execute positioned ^ ^ ^4 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^4 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..5]
execute positioned ^ ^ ^5 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^5 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..6]
execute positioned ^ ^ ^6 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^6 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..7]
execute positioned ^ ^ ^7 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^7 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..8]
execute positioned ^ ^ ^8 unless block ~ ~ ~ #bistro:nonsolid run return 0
execute positioned ^ ^-0.25 ^8 as @e[type=!#bistro:ignore,type=!#bistro:trap_immune,distance=..1.3] run return run damage @s 2.0 minecraft:fireball by @n[tag=bistro.flame_emitter,distance=..9]