tag @s remove bistro.open
playsound minecraft:block.grindstone.use block @a[distance=..16] ~ ~ ~ 1 0.7
playsound minecraft:block.piston.extend block @a[distance=..16] ~ ~ ~ 1 1
execute if entity @e[tag=bistro.bookshelves,distance=..1] run return run fill ~ ~-1 ~ ~ ~ ~ minecraft:bookshelf
execute if predicate bistro:in_jungle_stronghold run function bistro:tick_entities/technical/puzzles/lever_master/close/jungle
execute if predicate bistro:in_forest_stronghold run function bistro:tick_entities/technical/puzzles/lever_master/close/forest