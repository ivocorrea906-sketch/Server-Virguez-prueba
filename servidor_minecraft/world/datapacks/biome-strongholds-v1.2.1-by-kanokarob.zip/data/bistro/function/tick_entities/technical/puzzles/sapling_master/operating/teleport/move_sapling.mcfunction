tp @s ~ ~ ~
tag @s remove bistro.teleport
tag @n[tag=bistro.hiding_spot] add bistro.exhausted
playsound minecraft:block.grass.place block @a[distance=..16] ~ ~ ~