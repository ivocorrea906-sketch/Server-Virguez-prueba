execute if score @s bistro.timer matches 1.. run scoreboard players remove @s bistro.timer 1
execute unless score @s bistro.timer matches 1.. unless data entity @s {HurtTime:0s} run function bistro:tick_entities/mobs/witch/teleport
execute if entity @s[tag=bistro.ominous] as @e[type=minecraft:splash_potion,distance=..2] at @s run function bistro:tick_entities/mobs/witch/change_potion