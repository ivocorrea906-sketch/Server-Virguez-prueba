fill ^-1 ^-1 ^-1 ^1 ^1 ^1 air replace #bistro:secret_door_replaceable
playsound minecraft:block.grindstone.use block @a[distance=..16] ~ ~ ~ 1 0.7
playsound minecraft:ui.toast.challenge_complete block @a ~ ~ ~ 0.4 1.3
particle minecraft:poof ~ ~ ~ 0.5 0.5 0.5 0.05 20 normal
kill @s