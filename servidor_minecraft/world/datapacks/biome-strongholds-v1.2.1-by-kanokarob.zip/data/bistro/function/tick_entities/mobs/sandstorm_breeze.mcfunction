scoreboard players add @s bistro.timer 0
particle minecraft:falling_dust{block_state:"minecraft:sand"} ~ ~2 ~ 1 0.75 1 0 1 normal
execute unless entity @s[tag=bistro.sand_burst] if score @s bistro.timer matches 100.. if predicate bistro:chance/5 run function bistro:tick_entities/mobs/sandstorm_breeze/sand_burst_start
execute if entity @s[tag=bistro.sand_burst] run function bistro:tick_entities/mobs/sandstorm_breeze/sand_burst
scoreboard players add @s bistro.timer 1