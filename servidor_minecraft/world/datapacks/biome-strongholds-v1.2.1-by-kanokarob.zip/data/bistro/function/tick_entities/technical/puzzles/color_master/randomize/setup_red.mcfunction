tag @s add bistro.color.red
tag @s add bistro.initialized