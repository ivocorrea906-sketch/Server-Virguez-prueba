execute as @e[type=!marker,type=!block_display,distance=..1.5] at @s run damage @s 4.0 minecraft:falling_stalactite
playsound minecraft:block.pointed_dripstone.land block @a ~ ~ ~ 1 1
kill @s