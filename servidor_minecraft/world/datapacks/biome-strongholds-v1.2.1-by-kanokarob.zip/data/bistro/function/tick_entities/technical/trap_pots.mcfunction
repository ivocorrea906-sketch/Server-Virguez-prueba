execute if entity @s[tag=bistro.desert] run function bistro:trap_pots/desert
execute if entity @s[tag=bistro.ocean] run function bistro:trap_pots/ocean
execute if entity @s[tag=bistro.jungle] run function bistro:trap_pots/jungle
execute if entity @s[tag=bistro.ice] run function bistro:trap_pots/ice
execute if entity @s[tag=bistro.swamp] run function bistro:trap_pots/swamp
execute if entity @s[tag=bistro.forest] run function bistro:trap_pots/forest
kill @s