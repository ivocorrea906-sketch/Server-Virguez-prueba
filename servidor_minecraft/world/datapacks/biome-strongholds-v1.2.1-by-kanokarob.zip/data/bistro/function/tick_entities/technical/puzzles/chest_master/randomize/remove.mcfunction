setblock ~ ~ ~ air
particle poof ~ ~ ~ 0.3 0.3 0.3 0.01 5 normal
kill @s