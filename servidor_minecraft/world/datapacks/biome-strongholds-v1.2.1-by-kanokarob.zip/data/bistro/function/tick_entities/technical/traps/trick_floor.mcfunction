fill ~-3 ~-1 ~-3 ~3 ~-1 ~3 lava replace #bistro:trick_floor
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 1
playsound minecraft:block.suspicious_sand.break block @a ~ ~ ~ 1 1
particle poof ~ ~ ~ 1.5 0.1 1.5 0.01 30 normal
kill @s