scoreboard players remove @s[scores={bistro.timer=1..}] bistro.timer 1
execute anchored eyes run particle smoke ^ ^ ^ 0.2 0.2 0.2 0.005 1 normal
tag @s add bistro.attacker
execute unless score @s bistro.timer matches 1.. as @e[distance=..2.25,tag=!bistro.creeper,type=!#bistro:ignore] run function bistro:tick_entities/mobs/creeper/attack
tag @s remove bistro.attacker