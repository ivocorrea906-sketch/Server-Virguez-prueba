tag @s remove bistro.initialized
tag @s remove bistro.color.red
tag @s remove bistro.color.green
tag @s remove bistro.color.blue
tag @s remove bistro.color.yellow