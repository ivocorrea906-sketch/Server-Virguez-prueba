execute if predicate bistro:chance/05 run function bistro:tick_entities/technical/puzzles/color_master/operating/test/yellow/particles
execute if predicate bistro:block_yellow run tag @s add bistro.correct
execute unless predicate bistro:block_yellow run tag @s remove bistro.correct