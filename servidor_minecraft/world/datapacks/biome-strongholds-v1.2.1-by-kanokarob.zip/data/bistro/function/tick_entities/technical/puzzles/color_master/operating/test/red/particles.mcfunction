particle dust{color:[1.0f,0.0f,0.0f],scale:0.75f} ~ ~0.5 ~ 0.2 0.2 0.2 0 2 normal
particle flame ~ ~0.5 ~ 0.2 0.2 0.2 0 2 normal