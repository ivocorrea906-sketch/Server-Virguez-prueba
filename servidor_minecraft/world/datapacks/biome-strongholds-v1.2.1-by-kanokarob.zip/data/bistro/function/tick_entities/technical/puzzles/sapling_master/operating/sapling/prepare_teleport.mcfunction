data remove entity @s interaction
execute on vehicle run tag @s add bistro.teleport
playsound minecraft:entity.allay.ambient_with_item block @a[distance=..16] ~ ~ ~
playsound minecraft:block.grass.break block @a[distance=..16] ~ ~ ~
particle minecraft:tinted_leaves{"color":[0.1f,0.5f,0.25f,1.0f]} ~ ~0.5 ~ 0.3 0.3 0.3 0.05 10 normal