execute as @n[tag=bistro.bookshelf_reward,distance=..15] at @s run function bistro:tick_entities/technical/puzzles/bookshelf_master/correct/reward
playsound minecraft:ui.toast.challenge_complete block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.player.levelup block @a[distance=..16] ~ ~ ~ 1 2
kill @s