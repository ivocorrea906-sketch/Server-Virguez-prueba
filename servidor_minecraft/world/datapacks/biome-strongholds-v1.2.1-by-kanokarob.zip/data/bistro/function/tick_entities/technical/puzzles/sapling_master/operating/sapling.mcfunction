execute if predicate bistro:chance/50 run particle minecraft:dust{color:[0.425f,0.9f,1.0f],scale:0.65f} ~ ~0.5 ~ 0.3 0.3 0.3 0 3 normal
execute if predicate bistro:chance/5 run particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.01 2 normal
execute on passengers if data entity @s interaction run function bistro:tick_entities/technical/puzzles/sapling_master/operating/sapling/prepare_teleport