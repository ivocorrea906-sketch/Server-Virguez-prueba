setblock ~ ~-1 ~ minecraft:polished_granite
setblock ~ ~ ~ minecraft:cracked_stone_bricks