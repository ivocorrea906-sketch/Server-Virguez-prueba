tag @s add bistro.color.blue
tag @s add bistro.initialized