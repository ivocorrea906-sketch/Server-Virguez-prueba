execute if entity @s[tag=bistro.trick_floor] positioned ~-1 ~ ~-1 if entity @a[dx=1,dy=0,dz=1,predicate=bistro:on_ground] at @s run function bistro:tick_entities/technical/traps/trick_floor
execute if entity @s[tag=bistro.trick_ceiling] run function bistro:tick_entities/technical/traps/trick_ceiling
execute if entity @s[tag=bistro.spike] run function bistro:tick_entities/technical/traps/spike
execute if entity @s[tag=bistro.gas_emitter] run function bistro:tick_entities/technical/traps/gas_emitter
execute if entity @s[tag=bistro.flame_emitter] run function bistro:tick_entities/technical/traps/flame_emitter