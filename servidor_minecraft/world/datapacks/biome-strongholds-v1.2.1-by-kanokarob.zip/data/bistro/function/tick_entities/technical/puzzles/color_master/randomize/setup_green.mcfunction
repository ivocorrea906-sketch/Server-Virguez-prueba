tag @s add bistro.color.green
tag @s add bistro.initialized