rotate @s ~-3 0
particle minecraft:electric_spark ~ ~1 ~ 0.4 0.4 0.4 0.1 1 normal
execute if block ~ ~ ~ #minecraft:copper_chests unless data block ~ ~ ~ LootTable run function bistro:tick_entities/technical/puzzles/puzzle_chest/operating/opened
execute unless block ~ ~ ~ #minecraft:copper_chests run kill @s