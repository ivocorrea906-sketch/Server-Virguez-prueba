execute if predicate bistro:in_jungle_stronghold run place jigsaw bistro:jungle/deco/loot_treasure bistro:effect 1 ~ ~ ~
playsound minecraft:ui.toast.challenge_complete block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.player.levelup block @a[distance=..16] ~ ~ ~ 1 2
kill @e[tag=bistro.chest,tag=bistro.initialized,limit=4,distance=..14]
kill @s