execute as @e[tag=bistro.bookshelf,distance=..20,limit=4,sort=nearest] store result score @s bistro.state run random value 0..6
tag @s add bistro.initialized
playsound minecraft:block.trial_spawner.detect_player block @a[distance=..16] ~ ~ ~ 1 1.6 1
playsound minecraft:block.enchantment_table.use block @a[distance=..16] ~ ~ ~ 1 1.2 1