execute if block ~ ~0.1 ~ minecraft:end_portal_frame[eye=true] run return run kill @s
execute run summon minecraft:item_display ~ ~ ~ {Tags:[bistro.entity,bistro.portal_barrier.hat,smithed.entity,smithed.strict],item:{id:"minecraft:ice",count:1,components:{"minecraft:enchantment_glint_override":true}},transformation:{scale:[1.1f,1.1f,1.1f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.55f,0f]}}
ride @n[tag=bistro.portal_barrier.hat] mount @s
tag @e[tag=bistro.portal_key,tag=!bistro.initialized,distance=..120,limit=1,sort=random] add bistro.initialized