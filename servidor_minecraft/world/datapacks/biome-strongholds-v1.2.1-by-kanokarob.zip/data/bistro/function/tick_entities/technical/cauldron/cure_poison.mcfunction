effect clear @p[distance=..2.25,predicate=bistro:poisoned] minecraft:poison
playsound minecraft:entity.evoker.cast_spell block @a[distance=..16] ~ ~ ~ 1 1
particle poof ~ ~0.4 ~ 0.2 0.2 0.2 0.05 5 normal
execute if block ~ ~ ~ minecraft:water_cauldron[level=3] run return run setblock ~ ~ ~ minecraft:water_cauldron[level=2]
execute if block ~ ~ ~ minecraft:water_cauldron[level=2] run return run setblock ~ ~ ~ minecraft:water_cauldron[level=1]
execute if block ~ ~ ~ minecraft:water_cauldron[level=1] run setblock ~ ~ ~ minecraft:cauldron