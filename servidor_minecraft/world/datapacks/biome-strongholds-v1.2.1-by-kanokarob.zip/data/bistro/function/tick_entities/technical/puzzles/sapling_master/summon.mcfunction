tag @s add bistro.initialized
summon minecraft:block_display ~ ~ ~ {Tags:[bistro.entity,bistro.sapling,smithed.entity,smithed.strict],block_state:{Name:"minecraft:oak_sapling"},transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.5f,0.0f,-0.5f]}}
summon minecraft:interaction ~ ~ ~ {Tags:[bistro.entity,bistro.sapling_hat,smithed.entity,smithed.strict],response:1b}
ride @n[tag=bistro.sapling_hat,distance=..1] mount @n[tag=bistro.sapling,distance=..1]
playsound minecraft:block.trial_spawner.detect_player block @a[distance=..16] ~ ~ ~ 1 1.6 1
playsound minecraft:block.enchantment_table.use block @a[distance=..16] ~ ~ ~ 1 1.2 1