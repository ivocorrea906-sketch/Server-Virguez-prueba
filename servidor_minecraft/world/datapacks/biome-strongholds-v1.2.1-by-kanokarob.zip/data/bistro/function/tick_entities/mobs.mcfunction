execute if entity @s[type=minecraft:phantom,tag=bistro.phantom] run return run particle minecraft:white_ash ^ ^ ^-0.25 0.05 0.05 0.05 0.01 1 normal
execute if entity @s[type=minecraft:guardian,tag=bistro.praetor] run return run particle minecraft:ominous_spawning ~ ~0.25 ~ 0.2 0.2 0.2 1.75 8 normal
execute if entity @s[type=minecraft:vex,tag=bistro.vex] run return run particle minecraft:trial_omen ^ ^0.5 ^-0.5 0.2 0.2 0.2 0.005 1 normal
execute if entity @s[type=minecraft:creaking,tag=bistro.creaking] run return run effect give @e[tag=!bistro.entity,distance=..6.5,predicate=!bistro:blindness] minecraft:blindness 6 0 false
execute if entity @s[type=minecraft:breeze,tag=bistro.sandstorm] run function bistro:tick_entities/mobs/sandstorm_breeze
execute if entity @s[type=minecraft:breeze,tag=bistro.breeze.forest] run function bistro:tick_entities/mobs/forest_breeze
execute if entity @s[type=minecraft:elder_guardian,tag=bistro.elder] as @a[distance=..32,predicate=bistro:mining_fatigue] run function bistro:tick_entities/mobs/cursed_elder
execute if entity @s[type=minecraft:creeper,tag=bistro.creeper] run function bistro:tick_entities/mobs/creeper
execute if entity @s[type=minecraft:zombie,tag=bistro.ice_zombie] run function bistro:tick_entities/mobs/ice_zombie
execute if entity @s[type=minecraft:witch,tag=bistro.witch] run function bistro:tick_entities/mobs/witch