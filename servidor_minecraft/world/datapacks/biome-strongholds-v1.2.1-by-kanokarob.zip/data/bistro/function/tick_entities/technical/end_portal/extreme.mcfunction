particle reverse_portal ~ ~ ~ ^ ^ ^100000000 0.0000000055 0 normal
particle reverse_portal ~0.15 ~ ~ ^ ^ ^100000000 0.0000000055 0 normal
particle reverse_portal ~-0.15 ~ ~ ^ ^ ^100000000 0.0000000055 0 normal
particle reverse_portal ~ ~ ~0.15 ^ ^ ^100000000 0.0000000055 0 normal
particle reverse_portal ~ ~ ~-0.15 ^ ^ ^100000000 0.0000000055 0 normal