execute as @e[tag=bistro.color,tag=bistro.initialized,distance=..15] run function bistro:tick_entities/technical/puzzles/color_master/randomize/reset
execute as @e[tag=bistro.color,tag=!bistro.initialized,limit=1,sort=random,distance=..15] run function bistro:tick_entities/technical/puzzles/color_master/randomize/setup_red
execute as @e[tag=bistro.color,tag=!bistro.initialized,limit=1,sort=random,distance=..15] run function bistro:tick_entities/technical/puzzles/color_master/randomize/setup_green
execute as @e[tag=bistro.color,tag=!bistro.initialized,limit=1,sort=random,distance=..15] run function bistro:tick_entities/technical/puzzles/color_master/randomize/setup_blue
execute as @e[tag=bistro.color,tag=!bistro.initialized,limit=1,sort=random,distance=..15] run function bistro:tick_entities/technical/puzzles/color_master/randomize/setup_yellow
tag @s add bistro.initialized
setblock ~ ~ ~ minecraft:air
particle block{block_state:"minecraft:stone_button"} ~ ~ ~ 0.1 0.1 0.1 0.05 10 normal
playsound minecraft:block.trial_spawner.detect_player block @a[distance=..16] ~ ~ ~ 1 1.6 1