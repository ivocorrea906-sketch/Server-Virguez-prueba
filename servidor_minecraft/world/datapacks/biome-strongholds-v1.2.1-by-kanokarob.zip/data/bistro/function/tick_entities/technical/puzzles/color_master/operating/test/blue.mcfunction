execute if predicate bistro:chance/05 run function bistro:tick_entities/technical/puzzles/color_master/operating/test/blue/particles
execute if predicate bistro:block_blue run tag @s add bistro.correct
execute unless predicate bistro:block_blue run tag @s remove bistro.correct