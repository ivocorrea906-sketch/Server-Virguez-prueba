execute if block ~ ~ ~ minecraft:water_cauldron if predicate bistro:chance/5 run particle minecraft:witch ~ ~0.4 ~ 0.2 0 0.2 0.001 1 normal
execute unless block ~ ~ ~ #cauldrons run kill @s
execute if block ~ ~ ~ minecraft:water_cauldron if entity @a[distance=..2.25,predicate=bistro:poisoned] run function bistro:tick_entities/technical/cauldron/cure_poison