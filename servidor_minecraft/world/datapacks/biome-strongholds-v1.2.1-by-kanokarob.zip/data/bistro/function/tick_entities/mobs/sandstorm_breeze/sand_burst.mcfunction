particle minecraft:dust_pillar{block_state:"minecraft:sand"} ~ ~1 ~ 0.75 0.5 0.75 0 2 normal
playsound minecraft:entity.breeze.hurt hostile @a ~ ~ ~ 0.7 2
execute as @e[tag=!bistro.entity,distance=..2.5] at @s run damage @s 1 minecraft:wind_charge by @e[tag=bistro.sand_burst,limit=1,sort=nearest]
execute if score @s bistro.timer matches 40.. if predicate bistro:chance/5 run function bistro:tick_entities/mobs/sandstorm_breeze/sandstorm_breeze/sand_burst_end