scoreboard objectives add bistro.timer dummy
scoreboard objectives add bistro.timer.jumpless dummy
scoreboard objectives add bistro.timer.sound dummy
scoreboard objectives add bistro.state dummy
scoreboard objectives add bistro.temp dummy
scoreboard objectives add bistro.random dummy
forceload add 0 0