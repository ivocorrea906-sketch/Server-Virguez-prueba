playsound minecraft:entity.arrow.hit block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:item.firecharge.use block @a[distance=..16] ~ ~ ~ 1 1
particle dust{color:[1.0f,0.0f,0.0f],scale:0.65f} ~ ~ ~ 0.5 0.5 0.5 0.05 30 normal
particle poof ~ ~ ~ 0.3 0.3 0.3 0.05 10 normal
execute as @e[distance=..3] run damage @s 4.0 minecraft:arrow by @n[tag=bistro.trap_pot]
setblock ~ ~ ~ fire