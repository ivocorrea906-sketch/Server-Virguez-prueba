playsound minecraft:entity.creaking.activate block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.creaking.twitch block @a[distance=..16] ~ ~ ~ 1 1
particle minecraft:dust_pillar{block_state:"minecraft:resin_block"} ~ ~ ~ 0.5 0.5 0.5 0.05 30 normal
particle minecraft:entity_effect{color:[1.0f,0.65f,0.15f,1.0f]} ~ ~ ~ 0.3 0.3 0.3 0.05 10 normal
execute as @e[distance=..3] run function bistro:trap_pots/forest/effect