damage @s 4.0 minecraft:magic by @n[tag=bistro.trap_pot]
effect give @s minecraft:blindness 6 0 false