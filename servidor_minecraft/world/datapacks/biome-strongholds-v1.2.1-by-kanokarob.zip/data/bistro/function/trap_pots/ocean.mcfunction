playsound minecraft:entity.zombie.converted_to_drowned block @a[distance=..16] ~ ~ ~ 1 1
particle splash ~ ~ ~ 0.3 0.6 0.3 0.05 30 normal
particle sneeze ~ ~ ~ 0.5 0.5 0.5 0 8 normal
execute as @e[distance=..3] run function bistro:trap_pots/ocean/effect