playsound minecraft:entity.generic.explode block @a[distance=..16] ~ ~ ~ 1 1
particle explosion ~ ~ ~ 0 0 0 0 1 normal
particle large_smoke ~ ~ ~ 0.3 0.3 0.3 0.05 10 normal
particle smoke ~ ~ ~ 0.1 0.5 0.1 0 5 normal
execute as @e[distance=..3] run damage @s 4.0 minecraft:explosion by @n[tag=bistro.trap_pot]