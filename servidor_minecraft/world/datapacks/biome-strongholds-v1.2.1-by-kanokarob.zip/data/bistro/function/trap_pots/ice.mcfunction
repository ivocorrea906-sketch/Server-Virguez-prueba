playsound minecraft:block.snow.break block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.player.hurt_freeze block @a[distance=..16] ~ ~ ~ 1 1
particle snowflake ~ ~ ~ 0.5 0.5 0.5 0.05 30 normal
particle block{block_state:"minecraft:packed_ice"} ~ ~ ~ 0.3 0.3 0.3 0.05 10 normal
execute as @e[distance=..3] run function bistro:trap_pots/ice/effect