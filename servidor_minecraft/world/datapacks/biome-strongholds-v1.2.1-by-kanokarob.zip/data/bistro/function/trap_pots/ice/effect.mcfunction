damage @s 4.0 minecraft:freeze by @n[tag=bistro.trap_pot]
effect give @s minecraft:slowness 12 1 false