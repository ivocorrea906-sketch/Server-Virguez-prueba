damage @s 4.0 minecraft:spit by @n[tag=bistro.trap_pot]
effect give @s nausea 12 2 false