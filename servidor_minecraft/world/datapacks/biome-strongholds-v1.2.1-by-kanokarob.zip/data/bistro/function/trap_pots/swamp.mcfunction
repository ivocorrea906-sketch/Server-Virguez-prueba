playsound minecraft:entity.splash_potion.break block @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.witch.celebrate block @a[distance=..16] ~ ~ ~ 1 1
particle witch ~ ~ ~ 0.5 0.5 0.5 0.05 30 normal
particle minecraft:entity_effect{color:[0.85f,0.0f,0.0f,1.0f]} ~ ~ ~ 0.3 0.3 0.3 0.05 10 normal
execute as @e[distance=..3] run function bistro:trap_pots/swamp/effect