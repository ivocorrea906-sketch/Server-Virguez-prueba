rotate @s ~180 ~
playsound minecraft:entity.illusioner.mirror_move player @a[distance=..16] ~ ~ ~ 1 1
particle minecraft:poof ~ ~1 ~ 0.3 0.3 0.3 0.05 5 normal